# Autom8Lab Website

AI consulting agency website for **Autom8Lab** — helping traditional businesses adopt AI through consulting, training, and done-for-you implementation.

---

## Project Structure

```
autom8-website/
├── index.html              # LIVE — "Coming Soon" landing page
├── soon_index.html          # Full homepage template (placeholder copy, for future use)
├── services_menu.html       # 54 AI systems across 5 domains — accordion UI (partner-facing)
├── complexity_guide.html    # Same 54 systems sorted by complexity — tabbed UI (partner-facing)
├── css/
│   └── styles.css           # Shared design system (tokens, animations, components)
├── js/
│   └── main.js              # Shared JS (IntersectionObserver for fade-in animations)
├── assets/
│   └── logos/               # SVG brand assets (icon, logo-dark, logo-light, wordmark, favicon)
└── .claude/
    └── launch.json          # Dev server config (python3 http.server on port 8080)
```

## Pages

### `index.html` — Coming Soon (LIVE)
- **Purpose:** Public-facing landing page while the full site is being built.
- **Features:** Rotating headline (3 variants, 4s interval), Calendly CTA button, inline SVG logos.
- **Calendly link:** `https://calendly.com/cosminlungu/30min`
- **Headline rotator:** Vanilla JS using `display:none/block` swap + animation reflow trick (avoids gradient text ghosting).

### `soon_index.html` — Full Homepage (Template)
- **Purpose:** Future homepage with all 7 sections from the design brief. Contains placeholder copy.
- **Sections:** Hero, Problem, Solution, Services, How It Works, About, CTA/Footer.
- **Status:** Not live. Placeholder text needs replacing with final copy.

### `services_menu.html` — AI Service Menu (Partner-Facing)
- **Purpose:** Standalone page for partners showing all 54 AI systems organized by business domain.
- **Navigation:** Has its own nav with logo (unlinked) + "Book a Call" gold CTA → Calendly. Does NOT link to homepage.
- **UI:** Accordion pattern — Mega Categories → Categories → Individual Systems.
- **Interactivity:** Vanilla JS toggle functions (`toggleMega`, `toggleCategory`, `toggleSystem`).
- **Legend:** Links to complexity_guide.html with hash anchors (#quick, #medium, #major).
- **Contains its own `<style>` block** — extensive page-specific CSS for the accordion UI.

### `complexity_guide.html` — System Complexity Guide (Partner-Facing)
- **Purpose:** Same 54 systems but sorted by implementation complexity level.
- **Navigation:** Logo (unlinked) + "← Back to Service Menu" link.
- **UI:** Three tabs: Quick Wins (19 systems), Medium (25), Major (10).
- **Tab routing:** URL hash-based navigation (`#quick`, `#medium`, `#major`).
- **Contains its own `<style>` block** — page-specific CSS for the tabbed UI.

## Tech Stack

| Layer      | Tool                                   |
|------------|----------------------------------------|
| CSS        | Tailwind CSS via CDN + custom `styles.css` |
| Fonts      | Google Fonts — Inter (400–900)          |
| JS         | Vanilla JS (no frameworks)             |
| Hosting    | cPanel-compatible static files          |
| Dev server | `python3 -m http.server 8080`          |

## Design System

### Colors (CSS custom properties in `styles.css`)

| Token                | Value     | Usage                          |
|----------------------|-----------|--------------------------------|
| `--bg-page`          | `#0a0a0b` | Page background                |
| `--bg-card`          | `#141414` | Card/container backgrounds     |
| `--border-subtle`    | `#262626` | Dividers, borders              |
| `--text-primary`     | `#ffffff` | Headings, key text             |
| `--text-secondary`   | `#9ca3af` | Subheadings, descriptions      |
| `--text-muted`       | `#6b7280` | Captions, footer text          |
| `--accent-gold`      | `#c9a66b` | Primary brand accent (CTAs, "8" in logo) |
| `--accent-gold-hover`| `#d4b07a` | Gold hover state               |
| `--accent-teal`      | `#2dd4bf` | Secondary accent               |
| `--accent-purple`    | `#a78bfa` | Tertiary accent                |

### Mega-Category Colors (services_menu.html)

| Domain         | Color   | Hex       |
|----------------|---------|-----------|
| Leadership     | Purple  | `#a78bfa` |
| Revenue        | Green   | `#4ade80` |
| Delivery       | Blue    | `#60a5fa` |
| Internal Ops   | Orange  | `#fb923c` |
| Back Office    | Gray    | `#9ca3af` |

### Complexity Colors (complexity_guide.html)

| Level       | Color  | Hex       |
|-------------|--------|-----------|
| Quick Win   | Green  | `#4ade80` |
| Medium      | Yellow | `#facc15` |
| Major       | Red    | `#f87171` |

### Key CSS Classes

| Class              | Purpose                                            |
|--------------------|----------------------------------------------------|
| `.hero-gradient`   | Gradient text effect (gold → mauve) on headings     |
| `.fade-in`         | Scroll-triggered fade-up animation (needs `.visible` via JS) |
| `.headline-rotator`| Container for rotating headline items              |
| `.headline-item`   | Individual headline (hidden by default, `.active` shows it) |
| `.bg-glow`         | Fixed background with subtle radial glow effects   |
| `.cta-glow`        | Pulsing box-shadow animation on CTA buttons        |

## Shared JS (`js/main.js`)

Uses `IntersectionObserver` to add `.visible` class to `.fade-in` elements when they scroll into view (15% threshold). Each element only animates once (`unobserve` after triggering).

## Important Notes

### SVG Logos Are Inlined
All pages use **inline SVGs** rather than `<img>` references to `assets/logos/`. This was done because external SVG `<img>` tags broke on cPanel (MIME type issues). The files in `assets/logos/` are kept as source references but are not loaded by any page.

### Page Isolation
- `index.html` does **not** link to `services_menu.html` or `complexity_guide.html`.
- `services_menu.html` does **not** link back to `index.html` — it's a standalone partner tool.
- `complexity_guide.html` links back to `services_menu.html` only.
- This separation is intentional: the service pages are for partners, the homepage is for the public.

### Page-Specific Styles
`services_menu.html` and `complexity_guide.html` each contain large `<style>` blocks with page-specific CSS. These are not in the shared `styles.css` because they are self-contained interactive tools with unique UI patterns (accordions, tabs) that don't apply elsewhere.

### Adding New Pages
When creating new pages, include this boilerplate in `<head>`:
```html
<script src="https://cdn.tailwindcss.com"></script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<script>
  tailwind.config = {
    theme: {
      extend: {
        fontFamily: {
          sans: ['Inter', 'system-ui', 'sans-serif'],
        },
      },
    },
  }
</script>
<link rel="stylesheet" href="css/styles.css">
```
And include `<script src="js/main.js"></script>` before `</body>` for fade-in animations.

Inline the SVG logo/icon directly into the HTML (copy from an existing page) rather than using `<img>` tags.

## Dev Server

```bash
# Start local server (or use .claude/launch.json "autom8-dev" config)
cd /Users/cosmo/autom8-website
python3 -m http.server 8080
# Visit http://localhost:8080
```
